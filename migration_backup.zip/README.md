# STM32-ComDrivers

按功能选择、复制即用的嵌入式组件库。**开发 FOC 并输出日志时，只需复制 `FOC_demo/` 和 `LOG_demo/`。** 每个 demo 内部分为映射层、中间层、服务层，所需代码随目录一起带走。

这里的 demo 是可移植功能包，不是完整烧录工程。主函数、任务调度、CubeMX 配置、启动文件和具体业务由使用者的工程提供。

## 目录与选择

| 目录 | 功能 | 其他 demo 依赖 |
| --- | --- | --- |
| [FOC_demo](FOC_demo/README.md) | 坐标变换、空间矢量调制、增量式 PID、霍尔估算、电流/速度环、双线电机协议 | 无 |
| [LOG_demo](LOG_demo/README.md) | 环形缓冲、格式化日志、UART 输出映射 | 无 |
| [PID_demo](PID_demo/README.md) | 通用位置式和增量式 PID | 无 |
| [NAVIGATION_demo](NAVIGATION_demo/README.md) | GPS、航点、距离方位、航向控制、IMU 航向 | 无 |
| [NRF24L01_demo](NRF24L01_demo/README.md) | 无线收发及遥控载荷解析 | 无 |
| [DISPLAY_demo](DISPLAY_demo/README.md) | ILI9341、FT6336G、显示传输、可选 LVGL 8 适配 | 无 |
| [JOYSTICK_demo](JOYSTICK_demo/README.md) | 摇杆校准与单轴换算 | 无 |
| [BATTERY_demo](BATTERY_demo/README.md) | 采样滤波、电压补偿与电量换算 | 无 |
| [WS2812_demo](WS2812_demo/README.md) | 灯带波形编码及 PWM DMA 映射 | 无 |
| [LD14P_demo](LD14P_demo/README.md) | 雷达批次解析与网格转换 | 无 |
| [COMMAND_demo](COMMAND_demo/README.md) | 命令派发、PWM 命令、待修复的 SPI 帧接收器 | 无 |

```text
STM32-ComDrivers/
  FOC_demo/
    Mapping/       硬件接口、STM32F4 实现
    Middleware/    本功能需要的算法和协议
    Service/       电机控制服务
    README.md      复制和接入说明
    KNOWN_ISSUES.md 本功能待修复问题
    CMakeLists.txt 独立构建入口
  LOG_demo/        同样按上述三层组织
  ...其他 demo/
  docs/           架构、来源、集成、问题总表和备份
  tests/          组合使用与行为检查
  tools/          独立复制、依赖和编译检查
  cmake/          可选交叉编译工具链
```

纯算法功能没有实际映射或服务代码时，用层内说明文件解释边界。FOC 自带所需增量式 PID，不必再复制 PID_demo。日志只保存在 LOG_demo，由应用决定何时记录，电机算法不直接打印日志。各 demo 的硬件接口具有独立名称，可组合编译。

## 开发 FOC 并使用日志

1. 将 `FOC_demo/`、`LOG_demo/` 复制到目标工程同一父目录。
2. 编译两个目录的 `Middleware/`、`Service/` 下的 `.c`，将其父目录加入头文件搜索路径。
3. 使用 STM32F4 HAL 时，再编译各自 `Mapping/STM32F4/stm32f4_mapping.c`，由目标工程提供 HAL、CMSIS 和配置头文件；也可自行实现 `Mapping/mapping.h` 中的回调。
4. 在板级代码中连接 PWM、采样、角度和 UART，按固定周期更新电机，在主循环或任务中处理日志。

CMake 工程可直接使用两个 demo 自带的构建入口，无需复制本库根目录构建文件：

```cmake
add_subdirectory(FOC_demo)
add_subdirectory(LOG_demo)
target_link_libraries(firmware PRIVATE comdrivers_foc comdrivers_log)
```

具体配置与调用见 [FOC 接入](FOC_demo/README.md)、[日志接入](LOG_demo/README.md)和[集成说明](docs/INTEGRATION.md)。本库根目录 CMake 默认也只选择 FOC 和 LOG，通过 `COMDRIVERS_DEMOS=ALL` 可检查全部功能。

## 当前范围

代码来源为 CarMainControlBoard、FOC_EG2134、LVGL-_stm32f407vet6 及本库原有模块。三个源项目只读；使用这些 demo 不需要保留源项目。

本轮整理结构、命名、中文注释和依赖，**已登记的功能 bug 暂不修复**。各 demo 随附问题清单，总表见[待修复清单](docs/KNOWN_ISSUES.md)。编译、链接通过不等同于运行或实板验证。

- [分层与命名规则](docs/ARCHITECTURE.md)
- [来源与迁移位置](docs/MIGRATION.md)
- [验证记录](docs/VALIDATION.md)

历史目录备份见 `docs/migration/before_restructure.zip`；本次调整为独立 demo 前的版本保存在 `docs/migration/before_demo_layout.zip`。备份不参与构建。
