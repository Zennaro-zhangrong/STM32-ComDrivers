# 集成说明

## 选择功能目录

| 使用场景 | 复制的目录 |
| --- | --- |
| FOC 控制与日志 | FOC_demo、LOG_demo |
| 通用 PID 调参与日志 | PID_demo、LOG_demo |
| 导航与位置上报 | NAVIGATION_demo；需要日志时另加 LOG_demo |
| 屏幕、触摸与电量显示 | DISPLAY_demo、BATTERY_demo；页面布局由应用编写 |
| 摇杆无线遥控 | JOYSTICK_demo、NRF24L01_demo；数据调度由应用编写 |
| 雷达数据处理 | LD14P_demo |
| 灯带 | WS2812_demo |

每个目录均自包含，不需要复制本库的 docs、tests、tools、cmake 或根 CMakeLists。保持 demo 内部结构，把所选目录的父目录加入包含路径，编译各自 Middleware、Service 的 C 文件。DISPLAY 的 Service/Lvgl8 为可选项。

硬件实现通过 Mapping/mapping.h 中的回调注入。STM32F4 HAL 项目可编译各 demo 的 Mapping/STM32F4/stm32f4_mapping.c；其他平台实现同一接口即可。HAL、CMSIS、配置头文件、启动代码与链接脚本由集成工程提供。本库不依赖原三个源项目。

源码采用 C11，公共头文件支持 C++ 调用；使用相应数学函数的工具链需链接 m。

## FOC 与 LOG 组合

FOC_demo 内含电流环使用的增量式 PID，不需要再复制 PID_demo。LOG_demo 内含环形缓冲。两者分别通过 PWM 和字节输出合同连接硬件，没有交叉包含关系。

参见 [FOC 初始化与周期调用](../FOC_demo/README.md)和[UART 日志初始化](../LOG_demo/README.md)。每台电机持有独立 MotorControlService，每个日志实例持有独立缓冲区。角度、采样、速度反馈和调用周期由应用提供；日志在主循环或任务中处理。

## 接收与协议

- UART ISR只收集字节/通知任务。在任务中调用`NavigationService_Feed`或`WaypointDecoder_Feed`。`NavigationService_Upload`接收毫秒时间戳。
- `WaypointDecoder_Initialize`后设置`on_command`。业务命令0x0B/0x0C/0x0D由应用处理启停、语音；解析器不直接操作车灯或电机。
- 雷达输入必须是完整2632字节。调用`Ld14p_CheckHeaders`、`Ld14p_ParseBatch`、`Ld14p_ConvertGrid`。无CRC和残留点问题仍在；返回有效点数不代表下游已经按有效点数处理。
- 无线服务的`bus/chip_select/chip_enable/clock`全部设置后才能初始化。接收载荷地址只在回调期间有效；需要排队时复制到应用持有的缓冲区。回调不可重入同一无线实例。
- NRF32字节帧第2字节是载荷长度；目标库SPI36字节帧第2字节是整帧长度。两者不可混用。原SPI接收器仍有BUG-027，暂不作为可用接收链。
- 双数据线电机协议由板级发送32次同步时钟，片选拉高后再发一次提交时钟。`MotorLink_OnClock`是接收入口，不是普通SPI字节回调。

## 显示与触摸

用`DisplayStm32f4_MakeSpiWriter`提供ILI9341同步命令接口；`start_pixels`设置为`DisplayStm32f4_StartSpiPixels`，`pixel_context`指向相同SPI上下文。GPIO接口分别提供片选、数据/命令、复位。

```c
static void StartDisplayTransfer(void *context, const DisplayTransfer *transfer)
{
    Ili9341Service *screen = context;
    Ili9341_SetWindow(screen, transfer->left, transfer->top,
                     transfer->right, transfer->bottom);
    Ili9341_StartPixels(screen, transfer->pixels, transfer->byte_count);
}

static void OnDisplayDmaComplete(Ili9341Service *screen,
                                 DisplayTransferService *queue)
{
    Ili9341_FinishPixels(screen);
    DisplayTransfer_OnComplete(queue);
}
```

初始化队列时清零，设置`context=screen`、`start=StartDisplayTransfer`、`complete=Lvgl8Adapter_Complete`。应用`flush_cb`调用`Lvgl8Adapter_Flush`。板级`HAL_SPI_TxCpltCallback`先确认SPI句柄属于屏幕，再调用上面完成入口。错误回调需要应用处理，历史队列尚无失败恢复API。双owner通知错误见BUG-025。

RGB565要求与屏幕匹配的字节顺序，LVGL版本沿用源工程8.x；不内置LVGL源码。显示服务不分配绘图缓冲，也不注册全局回调。

触摸服务仅读取坐标。按压状态由应用读取中断引脚或按当前设备策略提供，使用`Lvgl8Adapter_SetTouch`转为LVGL数据；释放时保留上次坐标。


## CMake 接入

下面代码放在使用者工程中，firmware 目标应已由该工程创建：

```cmake
add_subdirectory(FOC_demo)
add_subdirectory(LOG_demo)
target_link_libraries(firmware PRIVATE comdrivers_foc comdrivers_log)
```

默认只编译可移植层。使用附带的 STM32F4 映射时，在 add_subdirectory 前设置 COMDRIVERS_ENABLE_STM32F4=ON、COMDRIVERS_STM32_INCLUDE_DIRS 为 HAL/CMSIS/配置头文件目录列表，COMDRIVERS_STM32_DEVICE 默认为 STM32F407xx。firmware 自身也需要这些外部头文件和芯片宏，并链接 HAL 实现。

DISPLAY 的 LVGL 8 适配通过 COMDRIVERS_ENABLE_LVGL8=ON 和 COMDRIVERS_LVGL_INCLUDE_DIRS 启用，实际 LVGL 库由使用者工程链接。

在本仓库内检查全部功能（主机需有 C 编译器）：

```powershell
cmake -S . -B build/host '-DCOMDRIVERS_DEMOS=ALL' -DCOMDRIVERS_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Debug
cmake --build build/host
ctest --test-dir build/host --output-on-failure
```

仅选择 FOC 与 LOG 可省略 COMDRIVERS_DEMOS，或使用 `'-DCOMDRIVERS_DEMOS=FOC;LOG'`。PowerShell 下须保留引号，避免分号被作为命令分隔符。

安装 ARM GCC 后，执行 `python tools/check_portability.py` 可将各 demo 复制到本库 build 内的独立目录，验证独立编译、组合头文件及链接。附加 `--source-root ..` 仅借用源项目已有 HAL/LVGL 头文件验证可选适配，输出仍仅写入本库。

交叉编译 CMake 可指定 `-DCMAKE_TOOLCHAIN_FILE=cmake/arm-none-eabi.cmake`。交叉编译的测试程序只能证明编译和链接完成，不能在 Windows 直接运行，也不是可直接烧录的完整固件。
