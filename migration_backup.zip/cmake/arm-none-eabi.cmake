# Cortex-M4F静态库交叉编译配置，不包含具体板卡链接脚本。
set(CMAKE_SYSTEM_NAME Generic)
set(CMAKE_SYSTEM_PROCESSOR arm)
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)
find_program(CMAKE_C_COMPILER arm-none-eabi-gcc REQUIRED)
find_program(CMAKE_AR arm-none-eabi-ar REQUIRED)
find_program(CMAKE_RANLIB arm-none-eabi-ranlib REQUIRED)
set(CMAKE_C_FLAGS_INIT "-mcpu=cortex-m4 -mthumb -mfpu=fpv4-sp-d16 -mfloat-abi=hard")
# 此设置只便于链接检查；真正的固件必须由板级工程提供启动代码、syscall与链接脚本。
set(CMAKE_EXE_LINKER_FLAGS_INIT "--specs=nosys.specs")
