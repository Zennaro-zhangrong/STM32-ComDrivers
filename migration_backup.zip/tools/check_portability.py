"""保留原检查入口；目前验证独立demo与组合移植。"""
from check_demos import main

if __name__ == '__main__':
    main()
