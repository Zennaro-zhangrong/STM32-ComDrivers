"""验证demo复制独立性、分层、公共头文件和组合链接；只写本库build目录。"""
from pathlib import Path
import argparse
import json
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', default=shutil.which('arm-none-eabi-gcc'))
    parser.add_argument('--source-root', type=Path, help='仅借用HAL/LVGL头文件做可选映射验证，仅读取')
    args = parser.parse_args()
    if not args.compiler:
        parser.error('需要arm-none-eabi-gcc，或用--compiler指定')
    build = ROOT/'build'
    build.mkdir(exist_ok=True)
    output = Path(tempfile.mkdtemp(prefix='demo-check-', dir=build))
    report = {'output':str(output), 'compiles':[], 'links':[], 'demos':[]}
    demos = sorted(ROOT.glob('*_demo'))
    assert demos, '没有demo可供验证'
    header_guards = {}
    for demo in demos:
        for path in demo.rglob('*.[ch]'):
            text = path.read_text(encoding='utf-8')
            for name in re.findall(r'#\s*include\s*"([^"]+)"', text):
                if name in ('stm32f4xx_hal.h','lvgl.h'):
                    assert ('STM32F4' in path.parts if name.startswith('stm32') else 'Lvgl8' in path.parts), path
                    continue
                dependency = (path.parent/name).resolve()
                assert dependency.is_file() and dependency.is_relative_to(demo.resolve()), (path, name)
                if 'Middleware' in path.parts:
                    assert dependency.is_relative_to((demo/'Middleware').resolve()), (path, dependency)
                if 'Mapping' in path.parts:
                    assert dependency.is_relative_to((demo/'Mapping').resolve()), (path, dependency)
            if 'STM32F4' not in path.parts and 'Lvgl8' not in path.parts:
                assert not re.search(r'#\s*include\s*[<\"][^>\"]*(?:stm32|main\.h|FreeRTOS|task\.h|semphr\.h|lvgl)', text, re.I), path
            if path.suffix == '.h':
                guard = re.search(r'#ifndef\s+(\w+)', text)
                assert guard and guard[1] not in header_guards, path
                header_guards[guard[1]] = str(path)
        report['demos'].append(demo.name)

    flags=['-std=c11','-mcpu=cortex-m4','-mthumb','-mfpu=fpv4-sp-d16','-mfloat-abi=hard',
           '-Wall','-Wextra','-Wpedantic','-Werror']
    hal_flags=[]; graphics_flags=[]
    if args.source_root:
        source_root=args.source_root.resolve()
        car=source_root/'CarMainControlBoard'
        hal_flags=['-DSTM32F407xx','-DUSE_HAL_DRIVER']
        for directory in ['Core/Inc','Drivers/STM32F4xx_HAL_Driver/Inc',
                          'Drivers/CMSIS/Device/ST/STM32F4xx/Include','Drivers/CMSIS/Include']:
            hal_flags += ['-I',str(car/directory)]
        display=source_root/'LVGL-_stm32f407vet6'
        graphics_flags=['-I',str(display/'lvgl'),'-I',str(display)]

    def run(command, collection, label):
        result=subprocess.run(command,cwd=ROOT,text=True,capture_output=True)
        report[collection].append({'label':label,'returncode':result.returncode,
                                   'diagnostics':result.stdout+result.stderr})
        if result.returncode:
            raise RuntimeError(label+'\n'+result.stdout+result.stderr)

    def compile_file(source, destination, includes=(), label=None):
        run([args.compiler,*flags,*includes,'-c',str(source),'-o',str(destination)],'compiles',label or str(source))

    def link(objects,destination):
        run([args.compiler,*flags,'--specs=nosys.specs',*[str(p) for p in objects],'-lm','-o',str(destination)],
            'links',str(destination.relative_to(output)))

    try:
        all_portable=[]; all_objects=[]; all_headers=[]
        empty_main=output/'empty_main.c'
        empty_main.write_text('int main(void) { return 0; }\n',encoding='utf-8')
        empty_main_object=output/'empty_main.o'
        compile_file(empty_main,empty_main_object)
        # 每个demo位于不同的复制目录；该编译只能看到本demo自己的文件。
        for demo in demos:
            parent=output/'isolated'/demo.name
            clone=parent/demo.name
            shutil.copytree(demo,clone)
            objects=[]
            for index,path in enumerate(sorted(clone.rglob('*.[ch]'))):
                optional='STM32F4' in path.parts or 'Lvgl8' in path.parts
                if optional and not args.source_root:
                    continue
                extra=hal_flags if 'STM32F4' in path.parts else graphics_flags if 'Lvgl8' in path.parts else []
                object_path=parent/(str(index)+'.o')
                source=path
                if path.suffix=='.h':
                    source=parent/(str(index)+'_header.c')
                    source.write_text('#include "'+path.as_posix()+'"\n',encoding='utf-8')
                    all_headers.append(path)
                compile_file(source,object_path,extra,label=demo.name+'/'+str(path.relative_to(clone)))
                if path.suffix=='.c':
                    all_objects.append(object_path)
                    if not optional:
                        objects.append(object_path)
                        all_portable.append(object_path)
            link([empty_main_object,*objects],parent/'standalone.elf')

        # 所有头文件放在同一翻译单元，检查类型、枚举和包含保护冲突。
        combined=output/'all_headers.c'
        combined.write_text('\n'.join('#include "'+p.as_posix()+'"' for p in all_headers)+'\n',encoding='utf-8')
        compile_file(combined,output/'all_headers.o',[*hal_flags,*graphics_flags])
        run([args.compiler,*flags,'-nostdlib','-r',*[str(p) for p in all_objects],'-o',str(output/'all_demos.o')],
            'links','all demos including selected platform adapters (relocatable)')

        # 独立目录只包含FOC与LOG，连测试也复制进去，不加入仓库根目录搜索路径。
        pair=output/'foc_log_only'
        pair.mkdir()
        for name in ['FOC_demo','LOG_demo']:
            shutil.copytree(ROOT/name,pair/name)
        shutil.copyfile(ROOT/'tests/test_foc_log.c',pair/'test_foc_log.c')
        pair_objects=[]
        sources=[p for p in pair.rglob('*.c') if 'STM32F4' not in p.parts]
        for index,source in enumerate(sorted(sources)):
            object_path=pair/(str(index)+'.o')
            compile_file(source,object_path,['-I',str(pair)])
            pair_objects.append(object_path)
        link(pair_objects,pair/'foc_log_tests.elf')

        # 全库原行为回归测试以所有demo的复制目录作为搜索路径。
        includes=[]
        for demo in demos:
            includes+=['-I',str(output/'isolated'/demo.name)]
        test_object=output/'test_components.o'
        compile_file(ROOT/'tests/test_components.c',test_object,includes)
        link([test_object,*all_portable],output/'all_components_tests.elf')
    finally:
        (build/'demo_validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('PASS:',len(demos),'standalone demos;',len(report['compiles']),'strict compile units;',len(report['links']),'links')
    print('FOC + LOG isolated copy check passed; behavior binaries linked, NOT executed; no hardware test.')


if __name__=='__main__':
    main()
