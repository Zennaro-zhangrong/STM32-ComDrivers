# 源模块与目标组件

当前顶层按独立 demo 组织，各 demo 内部按 Mapping、Middleware、Service 分层。三个源项目仅作为读取来源。源路径以下均相对于各项目根目录；本库不依赖这些项目才能使用。

## CarMainControlBoard

| 源文件/目录 | 本库去向 | 抽取边界 |
| --- | --- | --- |
| `Middleware/RingBuffer.c/.h` | `LOG_demo/Middleware/ring_buffer` | 合并重复实现，保留count算法 |
| `DriverLayer/Src/log.c` | `LOG_demo/Service` + `LOG_demo/Mapping/STM32F4` | 格式化/缓冲属于服务；HAL发送属于映射。RTOS DMA日志任务不复制 |
| `DriverLayer/Src/Motion.c` | `NAVIGATION_demo/Middleware` + `NAVIGATION_demo/Service` | 度分转换、距离方位、航向PI、到达判定；车辆启停/模式选择交还应用 |
| `DriverLayer/Src/gps.c` | `NAVIGATION_demo/Middleware/navigation_protocol` + `NAVIGATION_demo/Service/navigation_service` | RMC解析、行组装、位置上报和路线申请；ISR双缓冲/信号量由板级接收入口代替 |
| `DriverLayer/Src/g4.c` | `NAVIGATION_demo/Middleware/navigation_protocol` 中的 `WaypointDecoder` | 字节状态机与航点存储；零长度命令通过回调交付，语音/车灯不进入解析器 |
| `DriverLayer/Src/IMU.c` | `NAVIGATION_demo/Middleware/navigation_math` + `NAVIGATION_demo/Service/imu_heading_service` | 标定插值、航向读取；实车37点标定表由使用者按传感器提供 |
| `DriverLayer/Src/ld14p.c` | `LD14P_demo/Middleware/ld14p_parser` | 2632字节批次解析和网格转换；串口节拍、雷达转发任务由应用调度 |
| `DriverLayer/Src/NRF24L01.c` | `NRF24L01_demo/Service/nrf24l01_service` + `NRF24L01_demo/Middleware/remote_control_protocol` | 寄存器与收发、遥控载荷分离；接收回调交付数据，车辆动作不写进设备服务 |
| `DriverLayer/Src/FOC_communication.c` | `FOC_demo/Middleware/motor_link_protocol` + GPIO映射 | 抽取32位字编码；双数据线时序需按原协议由板级驱动 |
| `DriverLayer/Src/ws2812.c` | `WS2812_demo/Middleware/ws2812_encoder` + PWM DMA映射 | 保留GRB、亮度和波形编码；四块4×4灯板位置/图案/车辆灯语属于应用资源 |
| `Car.c/.h` | 不复制 | 全车单例、业务模式和各驱动交叉指针不适合成为通用库 |
| `task_Service.c/.h`、`HAL_Callback.c` | 接入说明 | 任务优先级、栈大小、HAL总回调属于具体工程 |
| `CMD_Layer` | `COMMAND_demo/Middleware/command_dispatcher` 的表/回调模式 | 源命令函数为空，不虚构停车等实现 |

## FOC_EG2134

| 源文件 | 本库去向 | 抽取边界 |
| --- | --- | --- |
| `MiddleLayer/Src/PID.c` | `FOC_demo/Middleware/incremental_pid`；通用版本见 `PID_demo/Middleware/pid_controller` | 增量式PID，与目标库位置式PID分开命名 |
| `clark_transformation.c`、`park_transformation.c` | `FOC_demo/Middleware/coordinate_transform` | Clarke拼写修正，去掉全局对象和无用HAL依赖 |
| `svpwm.c` | `FOC_demo/Middleware/space_vector_pwm` | 保留极坐标与直角坐标算法；开环测试时基属于应用 |
| `DriveLayer/Src/Hall_Sensor.c` | `FOC_demo/Middleware/hall_estimator` | 输入霍尔位图和时间戳；引脚读取留给映射 |
| `DriveLayer/Src/Motor.c` | `FOC_demo/Service/motor_control_service` | 采样换算、电流环、速度环、三相输出；参数/偏置/定时器/ADC配置由应用设置 |
| `DriveLayer/Src/DataReception.c` | `FOC_demo/Middleware/motor_link_protocol` + `MotorControl_SetDifferentialTarget` | 字节/位接收状态与双电机目标解耦；保留超时缺陷 |
| `PWM_EG2134.c` | `FOC_demo/Mapping/STM32F4` | 三相比较、主/互补输出启动；不复制写死TIM1/TIM8和开环测试 |
| `RingBuffer.c`、`UART2.c` | LOG_demo 的缓冲区和日志服务 | 不再重复复制 |
| `angle_progress.c/.h` | 不作为已实现模块移植 | 仅有未使用的静态饱和/角度函数和观察器结构，无完整滑模观察器入口；源饱和函数疑点见BUG-028 |

## LVGL-_stm32f407vet6

| 源文件/目录 | 本库去向 | 抽取边界 |
| --- | --- | --- |
| `Hardware/ADC.c` | `JOYSTICK_demo/Service/joystick_service` | 单轴中心校准、方向和正负增益；ADC通道/启动由应用管理 |
| `Hardware/BatteryVoltage.c` | `BATTERY_demo/Middleware` + `BATTERY_demo/Service` | 中值/均值、补偿、电量换算；传入负载电流，移除LCD和GUI全局依赖 |
| `Hardware/NRF24L01.c` | NRF24L01_demo 无线服务 + `NRF24L01_demo/Middleware/remote_control_protocol` | 保留固定帧；采用该工程1ms CE延时接口，主控空循环延时留作源问题记录 |
| `Hardware/UART.c`、`Middleware/RingBuffer.c` | LOG_demo 的日志/缓冲区 | 合并同功能模块 |
| `Screen_Driver/FT6336G.c` | `DISPLAY_demo/Service/ft6336g_service` | 原寄存器设置、两次首点采样、横屏转换；I2C注入 |
| `Screen_Driver/LCD.c` | `DISPLAY_demo/Service/ili9341_service` + `DISPLAY_demo/Service/display_transfer_service` | 原86项初始化命令/参数/延时序列，窗口、像素传输、双队列 |
| `Screen_Driver/SPI_cb.c` | 接入说明 | HAL完成回调由集成工程统一分发 |
| `lvgl/examples/porting/lv_port_disp.c`、`lv_port_indev.c` | `DISPLAY_demo/Service/Lvgl8` | 仅适配刷新/触摸接口；LVGL注册、缓冲分配仍由应用持有 |
| `lvgl/GUI/*` | 不复制具体页面 | 电池、摇杆、PID、无线设置、点云页面均是车辆UI；其数据计算/通信已抽为服务，布局/资源保留在源项目 |
| `zrCMD/*` | 通用命令表接口 | 多个空处理函数不作为完成的功能移入 |
| `lvgl/src`、HAL、CMSIS等第三方代码 | 不复制 | 使用者按项目管理第三方依赖；本库只保留适配代码 |

## 目标库原有文件

| 原目录 | 现在位置 |
| --- | --- |
| 三份`Middleware/ring_buffer` | 一份`LOG_demo/Middleware` |
| `PID_demo/Middleware/pid` | `PositionPidController` |
| `FOC_demo/Middleware/cmd_engine` | `CommandTable`，调用方直接持有，取消全局8表池 |
| `FOC_demo/Application/spi_cmd_table` | `COMMAND_demo/Service/pwm_command_service` |
| `FOC_demo/Mapping/mapping_spi` | `COMMAND_demo/Middleware/spi_frame_receiver`，明确标为待修复 |
| 各demo的日志/PWM/LED/时基映射 | 日志服务 + 按接口注入的STM32F4映射 |
| `app_log`、`app_pid`、`app_foc` | 主循环接入示例，模拟对象和应用初始化不作为库代码 |

本次开始时目标库已有暂存和未暂存改动，未执行reset、checkout、commit或暂存操作。旧文件完整保存于 `docs/migration/before_restructure.zip`，每个文件的SHA256见 `legacy_manifest.json`。该压缩包只用于恢复，不加入构建；源项目不会被打包到库中。

## 参数迁移提示

- 源无线配置：地址`34 43 56 65 78`、通道76、射频寄存器`0x0E`；服务不写死这些配置。原注释“250kbps”与实际宏`NRF_RF_2MBPS_0DBM`冲突，已按宏含义说明。
- 源摇杆通道顺序：左X=1、左Y=2、右X=3、右Y=4；方向分别为-1、+1、+1、-1。增益属于该摇杆标定，复制时逐轴设置，不移入公共常量。
- 源电池负载模型为`150 + brightness * 7.14`毫安；电路参数仍沿用原3.3V、3.4倍率公式。
- 源电机PWM最大比较值1679，D/Q增益1.1/0.05/0、限幅±300；速度增益2.5/0.055/0.05、限幅±260。两台电机ADC偏置/增益不同，必须分别设置。
- 霍尔初始化时间参数必须来自与OnEdge相同的高精度计数器；原工程初始化用HAL毫秒、后续用20kHz计数，已登记而不在映射中暗自换算。
- 位置、航点、远控和雷达各自采用不同数据格式，详见接口注释，不统一更换协议。

## 独立 demo 调整记录

原先集中在仓库根目录 Mapping、Middleware、Service 的功能已按使用场景拆入 11 个 demo。日志只保留在 LOG_demo；FOC 所需增量式 PID 内置且单独命名，支持与 PID_demo 同时链接。映射合同及 STM32F4 实现按功能裁剪并使用独立前缀。

调整前 57 个 C/头文件的 SHA256 记录在 `migration/before_demo_layout_manifest.json`，原结构备份为 `migration/before_demo_layout.zip`。迁移路径索引见 `migration/demo_file_map.json`；该索引记录移动的算法和服务，硬件映射属于按功能重新拆分的部分。历史备份不参与编译。
