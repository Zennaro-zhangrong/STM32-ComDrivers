# 验证记录

本次验证针对独立复制、分层边界和组合编译；功能缺陷仍按原编号保留。

## 独立移植检查

`python tools/check_portability.py --source-root ..` 已通过：11 个 demo、86 个严格编译单元、14 次链接。工具为每个 demo 创建独立副本，不把原仓库根目录加入编译搜索路径。

- 每个 demo 的源码和公共头文件可独立编译；可移植源码可独立链接。
- 头文件引用不得越出所属 demo；中间层不依赖映射或服务，映射不反向引用中间层或服务。
- 所有公共头文件可同时包含；所有对象组合链接无重复符号。
- 单独复制 FOC_demo、LOG_demo 后，组合测试可编译和链接，无 PID_demo 或公共目录依赖。
- STM32F4 映射和 LVGL 8 适配使用源项目现有依赖头文件编译。源项目仅读取，检查产物全部写入本库 build。
- 使用 ARM GNU Toolchain 15.2.1、C11、Cortex-M4F、硬浮点，以及 `-Wall -Wextra -Wpedantic -Werror`。

检查报告为 `build/demo_validation_report.json`，报告内记录独立副本的位置及各次编译、链接诊断。build 已忽略。

根目录 CMake 已分别选择默认 FOC/LOG 组合和 ALL 全部功能，完成 ARM 静态库构建及对应测试程序链接，输出位于 `build/cmake-demos-foc-log` 和 `build/cmake-demos-all`。

## 行为测试范围

`tests/test_foc_log.c` 覆盖两个电机实例的输出隔离及日志组合使用。`tests/test_components.c` 保留缓冲、PID、协议、显示等原行为断言。部分断言用于记录旧缺陷，后续修复时须同步更新。

测试程序已交叉编译并链接，**尚未执行**。本机未找到可用的主机 C 编译器，未做实板、DMA 压力、波形或电机闭环验证。nosys.specs 提供的系统调用桩可能产生链接警告，这些检查程序不是完整固件。

## 备份与来源

原 demo 工作区备份见 before_restructure.zip 与 legacy_manifest.json；本轮重新按功能分组前的结构备份见 before_demo_layout.zip 与 before_demo_layout_manifest.json，均在 docs/migration 下。删除旧集中目录前核对其 57 个 C/头文件与备份 SHA256 一致。

源项目读取指纹见 docs/migration/source_manifest.json；本轮收尾核对 82 项均保持一致。此前移植核对过 ILI9341 的 86 项初始化命令/参数/延时；本轮只调整归属和接口名称，未修改该序列。
