/** @file test_components.c
 * @brief 可在主机执行的合同与原行为回归测试；不将“保留缺陷”误写成修复后的期望。
 */
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>
#include <math.h>
#include <string.h>
#include "LOG_demo/Middleware/ring_buffer.h"
#include "PID_demo/Middleware/pid_controller.h"
#include "FOC_demo/Middleware/coordinate_transform.h"
#include "FOC_demo/Middleware/space_vector_pwm.h"
#include "NAVIGATION_demo/Middleware/navigation_protocol.h"
#include "NRF24L01_demo/Middleware/remote_control_protocol.h"
#include "FOC_demo/Middleware/motor_link_protocol.h"
#include "COMMAND_demo/Middleware/spi_frame_receiver.h"
#include "LD14P_demo/Middleware/ld14p_parser.h"
#include "WS2812_demo/Middleware/ws2812_encoder.h"
#include "LOG_demo/Service/log_service.h"
#include "DISPLAY_demo/Service/display_transfer_service.h"
#include "JOYSTICK_demo/Service/joystick_service.h"
#include "DISPLAY_demo/Service/ft6336g_service.h"
#include "FOC_demo/Service/motor_control_service.h"

static uint8_t written[32];
static size_t written_count;
static LogMappingStatus WriteBytes(void *context, const uint8_t *bytes, size_t count)
{
    assert(context == written);
    memcpy(written + written_count, bytes, count);
    written_count += count;
    return LOG_MAPPING_OK;
}
static void TestBufferAndLogging(void)
{
    RingBuffer buffer;
    uint8_t storage[3], value;
    RingBuffer_Initialize(&buffer, storage, 3);
    assert(!RingBuffer_ReadByte(&buffer, &value));
    assert(RingBuffer_WriteByte(&buffer, 1));
    assert(RingBuffer_WriteByte(&buffer, 2));
    assert(RingBuffer_WriteByte(&buffer, 3));
    assert(!RingBuffer_WriteByte(&buffer, 4));
    assert(RingBuffer_ReadByte(&buffer, &value) && value == 1);
    assert(RingBuffer_WriteByte(&buffer, 4));
    for (uint8_t expected = 2; expected <= 4; ++expected)
        assert(RingBuffer_ReadByte(&buffer, &value) && value == expected);
    LogService log;
    LogService_Initialize(&log, storage, 3, (LogMappingByteWriter){written, WriteBytes});
    LogService_Print(&log, "%s", "abcd");
    assert(LogService_Process(&log) == 3);
    assert(written_count == 3 && memcmp(written, "abc", 3) == 0);
}
static void TestMotorMath(void)
{
    ClarkeTransform first = {100, -50, -50, 0, 0}, second = {-100, 50, 50, 0, 0};
    Clarke_Forward(&first); Clarke_Forward(&second);
    assert(first.alpha == 100 && first.beta == 0 && second.alpha == -100);
    ParkTransform park = {100, -30, 0, 0, 0};
    Park_Forward(&park); assert(park.direct == 100 && park.quadrature == -30);
    Park_Inverse(&park); assert(park.alpha == 100 && park.beta == -30);
    IncrementalPidController controller = {.proportional_gain=1, .integral_gain=0.5f,
        .maximum_output=100, .minimum_output=-100};
    assert(IncrementalPid_Update(&controller, 10, 0) == 15);
    assert(IncrementalPid_Update(&controller, 10, 0) == 20);
    SpaceVectorPwm modulator = {.maximum_duty=1679};
    SpaceVectorPwm_FromPolar(&modulator, 0, 0);
    assert(modulator.duty_a == 839 && modulator.duty_b == 839 && modulator.duty_c == 839);
    for (int angle = 0; angle < 360; angle += 15) {
        SpaceVectorPwm_FromPolar(&modulator, 500, angle);
        assert(modulator.duty_a >= 0 && modulator.duty_a <= 1679);
        assert(modulator.duty_b >= 0 && modulator.duty_b <= 1679);
        assert(modulator.duty_c >= 0 && modulator.duty_c <= 1679);
    }
}
static void TestProtocols(void)
{
    NavigationPosition position = {0};
    assert(Navigation_ParseRmc("$GNRMC,120000,A,2500.000,N,12100.000,E,0,0,010126,,,A*00", &position));
    assert(position.latitude == 250000000 && position.longitude == 1210000000);
    NavigationPosition previous = position;
    assert(!Navigation_ParseRmc("$GNRMC,120000,V,2500.000,N,12100.000,E", &position));
    assert(position.latitude == previous.latitude && position.longitude == previous.longitude);
    WaypointDecoder decoder;
    NavigationPosition points[2];
    WaypointDecoder_Initialize(&decoder, points, 2);
    const uint8_t frame[] = {0x0A,0,8,0,0,0,42,0,0,0,24};
    for (unsigned index = 0; index < sizeof(frame); ++index) WaypointDecoder_Feed(&decoder, frame[index]);
    assert(WaypointDecoder_Read(&decoder, &position));
    assert(position.longitude == 42 && position.latitude == 24);
    assert(!WaypointDecoder_Read(&decoder, &position));
    /* BUG-013：未知带载荷帧保留卡住行为，留作集中修复时的对照。 */
    const uint8_t unknown[] = {0xFF,0,1,0};
    for (unsigned index = 0; index < sizeof(unknown); ++index) WaypointDecoder_Feed(&decoder, unknown[index]);
    assert(decoder.state == 3);
    RemoteControlInput input = {-200, 100, 50, -100, 0x12}, decoded = {0};
    uint8_t payload[9];
    RemoteControl_Encode(&input, payload); RemoteControl_Decode(&decoded, payload);
    assert(decoded.left_x == -200 && decoded.right_y == -100 && decoded.switches == 0x12);
    assert(MotorLink_PackJoystick(-1, 2) == 0xFFFF0002u);
    SpiFrameReceiver receiver = {0};
    assert(SpiFrameReceiver_NextAddress(&receiver) == NULL); /* BUG-027 */
}
static unsigned transfer_starts, completions;
static void *last_owner;
static void StartDisplay(void *context, const DisplayTransfer *transfer)
{
    assert(context == &transfer_starts && transfer->byte_count == 2);
    ++transfer_starts;
}
static void CompleteDisplay(void *owner) { last_owner = owner; ++completions; }
static void TestDisplayOwnership(void)
{
    DisplayTransferService display = {.context=&transfer_starts, .start=StartDisplay, .complete=CompleteDisplay};
    uint8_t pixels[2] = {0};
    int owner_a, owner_b;
    assert(DisplayTransfer_Enqueue(&display, &owner_a, 0,0,0,0,pixels) == 1);
    assert(DisplayTransfer_Enqueue(&display, &owner_b, 0,0,0,0,pixels) == 2);
    assert(transfer_starts == 1);
    DisplayTransfer_OnComplete(&display);
    assert(completions == 1 && last_owner == &owner_b); /* BUG-025 保留 */
    assert(transfer_starts == 2);
    DisplayTransfer_OnComplete(&display);
    assert(display.count == 0 && completions == 2);
}
static void TestEncodingAndInput(void)
{
    uint16_t samples[72];
    uint32_t green = 0x00800000;
    Ws2812_Encode(samples, &green, 1, 255, 30, 60);
    for (unsigned index = 0; index < 24; ++index) assert(samples[index] == 0);
    assert(samples[24] == 60 && samples[25] == 30 && samples[71] == 0);
    JoystickAxis axis = {.center_sample=2048, .direction=-1, .negative_gain=1, .positive_gain=1};
    Joystick_Update(&axis, 2128); assert(axis.value == -10);
    uint8_t polar[LD14P_POLAR_BYTES] = {0}, grid[LD14P_GRID_BYTES];
    polar[0] = 0x40; polar[1] = 0x1F; /* 8000 mm，角度0。 */
    Ld14p_ConvertGrid(polar, grid, 0);
    assert(grid[0] == 255 && grid[1] == 128 && grid[2] == 0);
}
int main(void)
{
    TestBufferAndLogging(); TestMotorMath(); TestProtocols();
    TestDisplayOwnership(); TestEncodingAndInput();
    return 0;
}
