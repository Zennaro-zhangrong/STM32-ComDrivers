/*
 * SPI.c
 *
 *	此文件的SPI配置为中断全双工从模式，CS引脚为双边沿触发外部中断模式
 *
 *	此文件涵盖36字节的【单缓冲发送】和【双缓冲接收】功能，与Hardware.h中的结构体高度耦合
 *
 *	接收结构为 0xCMD,0xLEN,0xDATA[2:35]，LEN表示1帧的总字节数，范围为3到36
 *
 *  Created on: 2026年3月30日
 *      Author: zr186
 */


#include "SPI.h"
#include "../Middleware/Buffer_scheduling/RingBuffer.h"
extern SPI_HandleTypeDef hspi1;

#define Transmit_SIZE 128
#define Recive_SIZE 128

static unsigned char Buffer_Transmait[Transmit_SIZE] = {0};
static unsigned char Buffer_Recive[Recive_SIZE] = {0};
RingBuffer SPI_Recive_Buffer = {0};
RingBuffer SPI_Transmit_Buffer = {0};

typedef enum{
	BUFFER_EMPTY,//缓冲区空，可用
	BUFFER_FULL,//当前缓冲区等待处理
	BUFFER_READ,//当前缓冲区正在被读取
	BUFFER_WRITE,//当前缓冲区正在被写入
	BUFFER_END,
	SPI_SEND_OK,
	SPI_SEND_ERROR,
	BUFFER_EMPTY,
	BUFFER_INIT_OK
}SPI_STATUS;

/**
 * @ 权限：用户修改
 * @ 功能：硬件的发送函数,每次发送1字节
 * @ 参数：SPI句柄
 * @ 参数：要发送的数据的地址
 * @ 返回：发送状态 
 */
static SPI_STATUS SPI_Transmit(SPI_HandleTypeDef *hpsi, unsigned char *PsendBuff){
	HAL_SPI_Transmit(hpsi, PsendBuff, 1 ,10);//这里替换为实际要发送的函数
}

/**
 * @权限：用户可以修改
 * @功能: 初始化创建的环形缓冲区
 */
void SPI_Init(void){
	RingBuffer_Init(&SPI_Recive_Buffer, Buffer_Recive, sizeof(Buffer_Recive));
	RingBuffer_Init(&SPI_Transmit_Buffer, Buffer_Transmait, sizeof(Buffer_Transmait));
}


/**
 * @权限： 用户不可修改
 * @功能： 实现缓冲区数据全部发送
 */
static SPI_STATUS SPI_Transmit_Data(void){
	if(SPI_Transmit_Buffer.count == 0) return BUFFER_EMPTY;//原因是无数据需要发送
	for(int i = 0; i < SPI_Transmit_Buffer.count; i++){
		unsigned char data;
		RingBuffer_ReadByte(&SPI_Transmit_Buffer, &data);
		SPI_STATUS state = SPI_Transmit(&hspi1, &data);
		if(state == SPI_SEND_ERROR) {
			return SPI_SEND_ERROR;
		}
	}
	return SPI_SEND_OK;
}



/*
 * 功能：判断最新接收的一个字节应该写入哪个接收缓冲区的哪个位置，
 * 		接收结构为 0xCMD,0xLEN,0xDATA[2:35]。
 * 输入：无
 * 返回：可以写入的物理内存地址
 */
static uint8_t* SPI_GetNextReceiveAddr(void){
	//判断写入缓冲区
	SPI_Data_Buffer * Buffer;
	if(SPI_Recive_Buffer_1.Buffer_Status == BUFFER_WRITE){
		Buffer = &SPI_Recive_Buffer_1;
	}else if(SPI_Recive_Buffer_2.Buffer_Status == BUFFER_WRITE){
		Buffer = &SPI_Recive_Buffer_2;
	}else if(SPI_Recive_Buffer_1.Buffer_Status == BUFFER_EMPTY){
		Buffer = &SPI_Recive_Buffer_1;
	}else if(SPI_Recive_Buffer_2.Buffer_Status == BUFFER_EMPTY){
		Buffer = &SPI_Recive_Buffer_2;
	}else return NULL;

	//判断写入地址
	uint8_t Cursor = Buffer->Buffer_Cursor;
	if(Cursor >= 36) return NULL;
	Buffer->Buffer_Cursor++;

	//判断帧尾
	if(Buffer->Data_Buffer[1] < 3 || Buffer->Data_Buffer[1] > 36){
		return NULL;
	}else if(Buffer->Buffer_Cursor == Buffer->Data_Buffer[1]){
		Buffer->Buffer_Status = BUFFER_FULL;
		Buffer->Buffer_Cursor = 0;
	}

	//发送地址
	return &(Buffer->Data_Buffer[Cursor]);
}




/*
 * @功能：SPI1的接收中断回调函数，务必放在HAL库的
 * HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)函数中
 *
 * @输入：SPI句柄
 *
 * @输出：无
 */
static void SPI1_RxCallback(SPI_HandleTypeDef *hspi)
{
    if(hspi == &hspi1){
    	uint8_t *nextAddr = SPI_GetNextReceiveAddr();
		if (nextAddr != NULL) {
			HAL_SPI_Receive_IT(&hspi1, nextAddr, 1);   // 启动下一个字节接收
		} else {
			UART_Printf("Receive error!Possible reasons:[1] Data too long, buffer overflow.[2] Incorrect format sent by the sender\r\n");
		}
    }
}



void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi){
	SPI1_RxCallback(hspi);
}
