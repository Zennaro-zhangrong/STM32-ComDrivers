# 待集中修复清单

本轮仅整理结构、接口、名称和注释。以下功能问题未修复；测试中对部分旧行为做了显式记录。`已确认`表示可由源代码直接判断，`待确认`表示需要硬件/协议/运行数据判断。编号将用于下一轮修复，不能把本清单当成所有缺陷都已找到的保证。

| 编号 | 状态与来源 | 触发条件/影响 | 本库位置与后续验证方向 |
| --- | --- | --- | --- |
| BUG-001 | 已确认；三个项目RingBuffer及无线接收计数 | 生产者和消费者均对count读改写，volatile不能避免丢更新；日志多调用者也无保护 | `LOG_demo/Middleware`、`LOG_demo/Service`；测试任务/中断交错。旧无线RTOS队列不复制，当前回调服务要求串行调用 |
| BUG-002 | 已确认/边界待定；目标库位置式PID | I<=0时积分限幅仍按0.001计算；输出转int16_t，过大配置越界且丢失小数 | `PID_demo/Middleware/pid_controller`；明确支持的增益符号、输出精度后修复 |
| BUG-003 | 已确认；FOC/svpwm.c | 角度、幅值整数化；幅值大于uint16_t范围时转换不可靠；极端角度加法可能溢出 | `FOC_demo/Middleware/space_vector_pwm`；扫描角度/幅值范围并做原算法对照 |
| BUG-004 | 已确认；目标库cmd_engine | 找到空handler仍返回成功 | `COMMAND_demo/Middleware/command_dispatcher`；下一轮明确派发结果枚举 |
| BUG-005 | 已确认；UART/log.c | 文本超255字节截断、队满静默丢失；发送前已出队，发送失败无法恢复 | `LOG_demo/Service/log_service`；回压、丢弃计数、失败重试和DMA寿命需一起设计 |
| BUG-006 | 已确认；Hall_GetFrequency | 扇区1～6和模6混用，5→6、6→1等边沿判断不一致；2000/周期不是已定义的机械转速 | `FOC_demo/Middleware/hall_estimator`；六扇区正反转序列、极对数和时基测试 |
| BUG-007 | 已确认；Hall_Init/OnEdge/Supervise | 初始化用HAL_GetTick、后续TIM7_GetTick；加法超时判断回绕；16位周期及倍增溢出 | `FOC_demo/Middleware/hall_estimator`保留周期/监督行为；初始tick成为参数，调用方仍须统一时基 |
| BUG-008 | 已确认；霍尔监督与角度插值 | 历史窗口最后一项未清空；pulse_period为0时除零；负向取模未统一到正角度 | `FOC_demo/Middleware/hall_estimator`；停转、反转、零周期测试 |
| BUG-009 | 已确认；Motor.c | 制动仅清输出不清误差历史；速度PID限幅后再加前馈，可能超过限幅；电流模式借用速度PID限幅 | `FOC_demo/Service/motor_control_service`；模式切换、饱和、恢复运行测试 |
| BUG-010 | 待平台确认；BatteryVoltage/average_filter | count转换为char，char有符号的平台在>=128时行为错误；窗口0无合法结果 | `BATTERY_demo/Middleware/sample_filter`；当前文档限制1～127，未更换算法 |
| BUG-011 | 已确认；Battery_Percentage_Get | 低于3.7V时先将负浮点转uint8_t再限幅；越界转换不可靠，可能得到高电量。预热不足也会触发；补偿电压*10000转uint16_t可能溢出 | `BATTERY_demo/Service/battery_service`；先确定电压、电量范围后修复，不能宣称低压输入安全 |
| BUG-012 | 已确认；gps.c/parse_rmc | strtok风格跳过空字段，字段错位；忽略NMEA校验和；无效定位不清旧位置；atof缺少格式/范围校验 | `NAVIGATION_demo/Middleware/navigation_protocol`、`NAVIGATION_demo/Service/navigation_service`；空字段、坏校验、长行、失锁测试 |
| BUG-013 | 已确认；g4_feed_byte/append | 未知非零长度命令卡在PAYLOAD；长度非8倍数遗留半个航点；signed左移高位存在未定义行为；无超时重同步 | `NAVIGATION_demo/Middleware/navigation_protocol` 中的 WaypointDecoder；坏帧、半帧、中途清空、负坐标测试 |
| BUG-014 | 已确认；Motion_Control | 转向先限幅后加机械偏置30，最终输出超出原限幅；积分回退与积分夹紧次序可能产生额外偏差 | `NAVIGATION_demo/Service/heading_control_service`；极限转向及长时间饱和测试 |
| BUG-015 | 已确认；LD14P_ParsePacket/Convert | 0～36000的角度存入int16_t，超过32767变负；跨零差值同样受16位转换影响 | `LD14P_demo/Middleware/ld14p_parser`；32767/32768/35999/0边界测试 |
| BUG-016 | 已确认；ld14p.c | 低置信度点被跳过后尾部未清，仍转换固定672点，残留上一批点；所谓crc函数只查包头 | `LD14P_demo/Middleware/ld14p_parser`；有效点骤减、坏CRC和跨批次残影测试 |
| BUG-017 | 已确认；NRF24L01_SendDatas | 正忙也返回成功且丢弃数据；没有可区分的送达状态；底层SPI失败被忽略 | `NRF24L01_demo/Service/nrf24l01_service`；忙、断线、SPI错误、超时测试 |
| BUG-018 | 已确认；NRF IRQ处理 | RX/TX/MAX_RT使用else-if，仅处理一种却清全部中断；读一帧就清RX FIFO可能丢积压帧 | `NRF24L01_demo/Service/nrf24l01_service`；同时置位和FIFO多帧测试 |
| BUG-019 | 已确认；FT6336G | I2C失败当0；width-y在y=0时得到越界的width；两次独立读取不保证同一触摸快照 | `DISPLAY_demo/Service/ft6336g_service`；四角、移动、断线、释放测试 |
| BUG-020 | 已确认/系数待定；IMU_GetYAW | 忽略总线失败；float字节直接memcpy假定小端IEEE754；弧度换算系数57.32484需核对 | `NAVIGATION_demo/Service/imu_heading_service`；通信错误和已知角度标定测试 |
| BUG-021 | 待硬件确认；ws2812_FillBuffer | 前后24个PWM周期的低电平是否满足复位时间，不能由原“>=50us”注释得出；brightness=254/255缩放不连续 | `WS2812_demo/Middleware/ws2812_encoder`；逻辑分析仪按实际周期测量。原单板更新停止所有通道属于板级策略，不复制 |
| BUG-022 | 已确认；DataReception.c | 接收未刷新lastTime，500ms后可能持续停车；bit_index>=32时移位未定义；不足32位也提交；超时比较不处理回绕 | `FOC_demo/Middleware/motor_link_protocol`；完整/短/长帧、持续通信和计数回绕测试 |
| BUG-023 | 已确认；主控NRF24L01_ProcessRxData | 未验证cmd/length就读data[8]；小载荷可能被解释为运动命令 | `NRF24L01_demo/Middleware/remote_control_protocol`明确至少9字节前提，外层验证仍需下一轮实现；无线回调length仍未验证 |
| BUG-024 | 已确认；LCD队列 | 超过2项/空出队永久死循环；RGB565字节数存uint16_t，大区域溢出；DMA启动失败不释放队列 | `DISPLAY_demo/Service/display_transfer_service`、`DISPLAY_demo/Service/ili9341_service`；满队列、整屏和启动失败测试 |
| BUG-025 | 已确认；LCD_SPI_TxCpltCallback | 先出队并移动B到A，再通知A的owner，可能通知到下一请求 | `DISPLAY_demo/Service/display_transfer_service`；两个不同owner的回归测试已记录旧行为 |
| BUG-026 | 已确认；Target_PointParsing | 最后航点读完不清目标，到达时不刷新下一点方位；0/0被当成无目标 | `NAVIGATION_demo/Service/navigation_service`；航点耗尽、相邻近点与零坐标测试 |
| BUG-027 | 已确认；目标库mapping_spi | 接收首字节前检查未到达的LEN；未建立WRITING状态；末字节完成前就标FULL；没有恢复流程 | `COMMAND_demo/Middleware/spi_frame_receiver`；当前不可直接作为可用接收器，下一轮重建状态机 |
| BUG-028 | 待需求确认；FOC/angle_progress.c | 饱和函数区间内x/limit、区间外返回±limit，limit!=1时可能不连续；limit=0除零 | 未移植未完成观察器；需先确认预期输出尺度 |
| BUG-029 | 已确认；源应用接收/显示/任务 | GPS任务提前释放ready导致ISR可能覆盖解析中行；图形库在NRF中断更新；task_Service不检查任务创建结果；禁用刷新时不通知LVGL完成 | 这些板级/应用流程未复制；集成时应单独设计并验证，不将其称为本库已修复 |
| BUG-030 | 待硬件确认；主控FOC_communication/NRF发送 | 空for循环延时可被优化，GPIO通信和CE脉宽无保证；源两项目射频/时序注释有冲突 | 本库将时基/引脚作为接口，NRF选用遥控器原1ms延时；双线发送时序仍需板级示波器验证 |

建议后续按“协议内存与状态机 → 并发/缓冲所有权 → 电机反馈与模式切换 → 显示与设备错误恢复 → 数值精度”分批修复。每批先把对应旧行为测试替换为期望行为测试，再修改实现。
